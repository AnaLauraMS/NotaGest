// Importa o Mongoose para interagir com o MongoDB
const mongoose = require('mongoose');
// Carrega as variáveis de ambiente
require('dotenv').config();

// Função assíncrona para conectar ao banco de dados
const connectDB = async () => {
    try {
        // Tenta conectar ao MongoDB usando a URI do arquivo .env
        await mongoose.connect(process.env.MONGO_URI);
        console.log('MongoDB conectado com sucesso!');
    } catch (err) {
        // Em caso de erro, exibe a mensagem de erro e encerra o processo
        console.error('Erro de conexão com o MongoDB:', err.message);
        process.exit(1);
    }
};

// Exporta a função de conexão para ser usada em server.js
module.exports = connectDB;